import  { useState } from 'react';
import { PixelButton } from './components/PixelButton';
import { WebGLFrame } from './components/WebGLFrame';
import { AnimatedHero } from './components/AnimatedHero';
import { YouTubeEmbed } from './components/YouTubeEmbed';

function App() {
  const [showWebGL, setShowWebGL] = useState(false);
  
  const handleDownload = () => {
    // This will be updated with the actual APK download URL
    window.open('#', '_blank');
  };
  
  const handlePlayNow = () => {
    // Open the cyber-pixel-verse.lovable.app URL in a new tab
    window.open('https://cyber-pixel-verse.lovable.app', '_blank');
    setShowWebGL(true);
  };

  return (
    <div className="min-h-screen flex flex-col cyberpunk-overlay font-pixel text-white">
      {/* Header with YouTube Video */}
      <header className="relative w-full h-[56.25vw] mb-8">
        <AnimatedHero />
        
        {/* YouTube Video full width with proper sizing */}
        <div className="w-full h-full relative z-10">
          <YouTubeEmbed videoId="ugKtR2swTYQ" />
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 container mx-auto p-6 flex flex-col items-center">
        {/* Buttons Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-12 my-8 w-full max-w-2xl mx-auto">
          <PixelButton 
            label="Download App" 
            icon="download"
            onClick={handleDownload} 
            className="animate-float"
          />
          
          <PixelButton 
            label="Experience Now" 
            icon="play"
            onClick={handlePlayNow} 
            className="animate-float" 
          />
        </div>

        {/* WebGL Frame Section */}
        {showWebGL && (
          <div className="w-full my-8">
            <WebGLFrame />
          </div>
        )}

        {/* Features Grid */}
        {!showWebGL && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full max-w-4xl mx-auto my-8">
            <div className="bg-deep-black/80 p-4 white-neon-box">
              <h3 className="text-neon-green mb-3 red-neon-text">Retro-Futuristic UI</h3>
              <p className="text-xs md:text-sm red-neon-text">Experience cybersecurity through a nostalgic 8-bit interface designed to make learning engaging.</p>
            </div>
            
            <div className="bg-deep-black/80 p-4 white-neon-box">
              <h3 className="text-neon-green mb-3 red-neon-text">Mobile Ready</h3>
              <p className="text-xs md:text-sm red-neon-text">Take SentinelVerse with you as a fully-featured Android application with the same pixel-perfect experience.</p>
            </div>
            
            <div className="bg-deep-black/80 p-4 white-neon-box">
              <h3 className="text-neon-green mb-3 red-neon-text">WebGL Experience</h3>
              <p className="text-xs md:text-sm red-neon-text">Play directly in your browser with our optimized WebGL build for desktops and laptops.</p>
            </div>
            
            <div className="bg-deep-black/80 p-4 white-neon-box">
              <h3 className="text-neon-green mb-3 red-neon-text">GSoC 2025</h3>
              <p className="text-xs md:text-sm red-neon-text">A project developed under Google Summer of Code 2025 by Nexus Coders United.</p>
            </div>
          </div>
        )}
      </main>

      {/* Footer with marquee */}
      <footer className="bg-deep-black/90 py-6 relative overflow-hidden">
        {/* Marquee text */}
        <div className="marquee-container overflow-hidden py-2 mb-4">
          <div className="marquee-content text-white red-neon-text text-sm">
            •Google Summer of Code 2025 by Nexus Coders United•
          </div>
        </div>
      </footer>
      
      {/* Added Neon Pointed Dots in Background */}
      <div className="neon-dots-container"></div>
    </div>
  );
}

export default App;
 