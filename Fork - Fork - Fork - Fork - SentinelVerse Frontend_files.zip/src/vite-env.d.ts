///  <reference types="vite/client" />
 