import  { useEffect, useState } from 'react';

export const AnimatedHero = () => {
  const [glitchActive, setGlitchActive] = useState(false);
  
  useEffect(() => {
    // Create glitch effect at random intervals
    const glitchInterval = setInterval(() => {
      setGlitchActive(true);
      setTimeout(() => setGlitchActive(false), 100 + Math.random() * 200);
    }, 2000 + Math.random() * 3000);
    
    return () => clearInterval(glitchInterval);
  }, []);

  return (
    <div className="absolute inset-0 z-0 overflow-hidden">
      {/* Static base image - Using the provided image */}
      <div className="absolute inset-0">
        <img 
          src="https://images.unsplash.com/photo-1577451581377-523b0a03bb6b?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHwxfHxjeWJlcnB1bmslMjByZXRybyUyMDhiaXQlMjBwaXhlbCUyMGFydCUyMGdyZWVuJTIwZ3JpZHxlbnwwfHx8fDE3NDQ2MjUwNTR8MA&ixlib=rb-4.0.3&fit=fillmax&h=720&w=1280" 
          alt="Green cyber texture" 
          className="w-full h-full object-cover"
          style={{ 
            imageRendering: 'pixelated', 
            filter: 'brightness(0.6) contrast(1.2) saturate(1.4) hue-rotate(10deg)'
          }}
        />
      </div>

      {/* Pixelated Overlay Grid */}
      <div 
        className="absolute inset-0 opacity-25 pointer-events-none"
        style={{ 
          backgroundImage: 'linear-gradient(0deg, transparent 24%, rgba(0, 255, 0, 0.3) 25%, rgba(0, 255, 0, 0.3) 26%, transparent 27%, transparent 74%, rgba(0, 255, 0, 0.3) 75%, rgba(0, 255, 0, 0.3) 76%, transparent 77%), linear-gradient(90deg, transparent 24%, rgba(0, 255, 0, 0.3) 25%, rgba(0, 255, 0, 0.3) 26%, transparent 27%, transparent 74%, rgba(0, 255, 0, 0.3) 75%, rgba(0, 255, 0, 0.3) 76%, transparent 77%)',
          backgroundSize: '40px 40px' 
        }}
      />

      {/* Glitch effect overlay */}
      <div className={`absolute inset-0 ${glitchActive ? 'opacity-100' : 'opacity-0'} transition-opacity duration-100`}>
        <img 
          src="https://images.unsplash.com/photo-1577451581377-523b0a03bb6b?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHwxfHxjeWJlcnB1bmslMjByZXRybyUyMDhiaXQlMjBwaXhlbCUyMGFydCUyMGdyZWVuJTIwZ3JpZHxlbnwwfHx8fDE3NDQ2MjUwNTR8MA&ixlib=rb-4.0.3&fit=fillmax&h=720&w=1280"
          alt="Glitch effect" 
          className="w-full h-full object-cover"
          style={{ 
            imageRendering: 'pixelated', 
            filter: 'hue-rotate(90deg) brightness(1.5) contrast(1.5)',
            transform: glitchActive ? 'translate(-5px, 3px)' : 'none'
          }}
        />
      </div>

      {/* Digital Code Lines - added for cyber effect */}
      <div className="absolute inset-0 opacity-15">
        <div 
          className="w-full h-full"
          style={{
            backgroundImage: 'radial-gradient(rgba(0, 255, 0, 0.1) 1px, transparent 1px)',
            backgroundPosition: '0 0',
            backgroundSize: '4px 4px'
          }}
        />
      </div>

      {/* Horizontal scan lines */}
      <div className="absolute inset-0 pointer-events-none">
        <div 
          className="w-full h-full" 
          style={{ 
            backgroundImage: 'repeating-linear-gradient(transparent 0px, transparent 1px, rgba(0, 0, 0, 0.25) 2px, rgba(0, 0, 0, 0.25) 3px)',
            backgroundSize: '4px 4px'
          }}
        />
      </div>

      {/* Moving scanline */}
      <div className="absolute inset-0 scanline pointer-events-none"></div>

      {/* Pixel noise - animated dots */}
      {Array.from({ length: 70 }).map((_, i) => (
        <div 
          key={i}
          className="absolute h-[2px] w-[2px] bg-neon-green rounded-full"
          style={{ 
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            opacity: Math.random() * 0.8 + 0.2,
            animation: `blink ${0.5 + Math.random() * 2}s infinite ${Math.random() * 2}s`
          }}
        />
      ))}

      {/* Gradient overlay to ensure text readability */}
      <div className="absolute inset-0 bg-gradient-to-t from-deep-black/95 via-deep-black/50 to-deep-black/20"></div>
    </div>
  );
};
 