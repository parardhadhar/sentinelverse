interface  PixelatedImageProps {
  src: string;
  alt: string;
  className?: string;
}

export const PixelatedImage = ({ src, alt, className = '' }: PixelatedImageProps) => {
  return (
    <div className={`relative overflow-hidden ${className}`}>
      <img 
        src={src} 
        alt={alt} 
        className="w-full h-full object-cover"
        style={{ imageRendering: 'pixelated' }}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-deep-black/80 to-transparent z-0"></div>
    </div>
  );
};
 