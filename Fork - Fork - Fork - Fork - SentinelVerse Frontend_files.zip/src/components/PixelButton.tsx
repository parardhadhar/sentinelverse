import  { useState, useEffect } from 'react';

interface PixelButtonProps {
  label: string;
  onClick: () => void;
  icon: 'download' | 'play';
  className?: string;
}

export const PixelButton = ({ label, onClick, className = '' }: PixelButtonProps) => {
  const [isGlitching, setIsGlitching] = useState(false);
  
  useEffect(() => {
    // Random glitch effect
    const glitchInterval = setInterval(() => {
      const shouldGlitch = Math.random() > 0.7;
      if (shouldGlitch) {
        setIsGlitching(true);
        setTimeout(() => setIsGlitching(false), 150);
      }
    }, 2000);
    
    return () => clearInterval(glitchInterval);
  }, []);

  return (
    <button 
      onClick={onClick} 
      className={`glitch-container pixel-button text-white font-pixel py-4 px-6 flex items-center justify-center gap-3 green-neon-button ${className} ${isGlitching ? 'glitch-effect' : ''}`}
    >
      <div className={`flex items-center justify-center ${isGlitching ? 'glitch-text' : 'white-neon-text'}`}>
        <span>{label}</span>
      </div>
    </button>
  );
};
 