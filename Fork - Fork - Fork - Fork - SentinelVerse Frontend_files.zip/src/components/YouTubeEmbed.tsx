interface  YouTubeEmbedProps {
  videoId: string;
  className?: string;
}

export const YouTubeEmbed = ({ videoId, className = '' }: YouTubeEmbedProps) => {
  return (
    <div className={`w-full h-full relative overflow-hidden ${className}`}>
      <iframe
        src={`https://www.youtube.com/embed/${videoId}?autoplay=1&mute=1&rel=0&controls=0&showinfo=0&loop=1&playlist=${videoId}&modestbranding=1&iv_load_policy=3&disablekb=1&cc_load_policy=0&fs=0&color=white&playsinline=1`}
        title="SentinelVerse Showcase"
        frameBorder="0"
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
        allowFullScreen
        className="absolute top-0 left-0 w-full h-full"
      ></iframe>
      
      {/* Full overlay to prevent any interaction with the video */}
      <div className="absolute top-0 left-0 w-full h-full z-10"></div>
    </div>
  );
}
 