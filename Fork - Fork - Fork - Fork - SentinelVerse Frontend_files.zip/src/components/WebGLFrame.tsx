import  { useState } from 'react';

interface WebGLFrameProps {
  className?: string;
}

export const WebGLFrame = ({ className = '' }: WebGLFrameProps) => {
  const [isLoaded, setIsLoaded] = useState(false);

  return (
    <div className={`relative w-full max-w-5xl mx-auto ${className}`}>
      <div className="pixel-border bg-deep-black/80 p-1 overflow-hidden">
        {!isLoaded && (
          <div className="absolute inset-0 flex items-center justify-center bg-deep-black">
            <div className="font-pixel text-neon-green animate-pulse text-center px-4">
              Loading WebGL Experience...
            </div>
          </div>
        )}
        
        <iframe 
          src="about:blank" /* Will be updated with actual WebGL URL */
          width="100%" 
          height="600" 
          frameBorder="0"
          className="w-full"
          onLoad={() => setIsLoaded(true)}
        />
        
        <div className="absolute top-0 left-0 w-full h-full pointer-events-none scanline"></div>
      </div>
    </div>
  );
};
 